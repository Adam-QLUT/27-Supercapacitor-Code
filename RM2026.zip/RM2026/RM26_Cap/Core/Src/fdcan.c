/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    fdcan.c
  * @brief   This file provides code for the configuration
  *          of the FDCAN instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "fdcan.h"

/* USER CODE BEGIN 0 */
uint32_t TxMailbox,TxMailbox01;
int a = 0;

/* USER CODE END 0 */

FDCAN_HandleTypeDef hfdcan2;

/* FDCAN2 init function */
void MX_FDCAN2_Init(void)
{

  /* USER CODE BEGIN FDCAN2_Init 0 */

  /* USER CODE END FDCAN2_Init 0 */

  /* USER CODE BEGIN FDCAN2_Init 1 */

  /* USER CODE END FDCAN2_Init 1 */
  hfdcan2.Instance = FDCAN2;
  hfdcan2.Init.ClockDivider = FDCAN_CLOCK_DIV1;
  hfdcan2.Init.FrameFormat = FDCAN_FRAME_CLASSIC;
  hfdcan2.Init.Mode = FDCAN_MODE_NORMAL;
  hfdcan2.Init.AutoRetransmission = DISABLE;
  hfdcan2.Init.TransmitPause = DISABLE;
  hfdcan2.Init.ProtocolException = DISABLE;
  hfdcan2.Init.NominalPrescaler = 6;
  hfdcan2.Init.NominalSyncJumpWidth = 7;
  hfdcan2.Init.NominalTimeSeg1 = 20;
  hfdcan2.Init.NominalTimeSeg2 = 7;
  hfdcan2.Init.DataPrescaler = 6;
  hfdcan2.Init.DataSyncJumpWidth = 7;
  hfdcan2.Init.DataTimeSeg1 = 20;
  hfdcan2.Init.DataTimeSeg2 = 7;
  hfdcan2.Init.StdFiltersNbr = 5;
  hfdcan2.Init.ExtFiltersNbr = 0;
  hfdcan2.Init.TxFifoQueueMode = FDCAN_TX_FIFO_OPERATION;
  if (HAL_FDCAN_Init(&hfdcan2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN FDCAN2_Init 2 */

  /* USER CODE END FDCAN2_Init 2 */

}

void HAL_FDCAN_MspInit(FDCAN_HandleTypeDef* fdcanHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};
  if(fdcanHandle->Instance==FDCAN2)
  {
  /* USER CODE BEGIN FDCAN2_MspInit 0 */

  /* USER CODE END FDCAN2_MspInit 0 */

  /** Initializes the peripherals clocks
  */
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_FDCAN;
    PeriphClkInit.FdcanClockSelection = RCC_FDCANCLKSOURCE_PCLK1;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
    {
      Error_Handler();
    }

    /* FDCAN2 clock enable */
    __HAL_RCC_FDCAN_CLK_ENABLE();

    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**FDCAN2 GPIO Configuration
    PB5     ------> FDCAN2_RX
    PB6     ------> FDCAN2_TX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF9_FDCAN2;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* FDCAN2 interrupt Init */
    HAL_NVIC_SetPriority(FDCAN2_IT0_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(FDCAN2_IT0_IRQn);
  /* USER CODE BEGIN FDCAN2_MspInit 1 */

  /* USER CODE END FDCAN2_MspInit 1 */
  }
}

void HAL_FDCAN_MspDeInit(FDCAN_HandleTypeDef* fdcanHandle)
{

  if(fdcanHandle->Instance==FDCAN2)
  {
  /* USER CODE BEGIN FDCAN2_MspDeInit 0 */

  /* USER CODE END FDCAN2_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_FDCAN_CLK_DISABLE();

    /**FDCAN2 GPIO Configuration
    PB5     ------> FDCAN2_RX
    PB6     ------> FDCAN2_TX
    */
    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_5|GPIO_PIN_6);

    /* FDCAN2 interrupt Deinit */
    HAL_NVIC_DisableIRQ(FDCAN2_IT0_IRQn);
  /* USER CODE BEGIN FDCAN2_MspDeInit 1 */

  /* USER CODE END FDCAN2_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */
void can_filter_init(void) 
{
  static FDCAN_FilterTypeDef can_filter_st; //FDCANčżćť¤ĺ¨çťćä˝
	
  can_filter_st.IdType = FDCAN_STANDARD_ID;             //ć ĺID
  can_filter_st.FilterIndex = 0;                        //čżćť¤ĺ¨ĺşĺ?
  can_filter_st.FilterType = FDCAN_FILTER_MASK;         //ćŠç ć¨Ąĺź
  can_filter_st.FilterConfig = FDCAN_FILTER_TO_RXFIFO0; //FIFO0ćĽćś
  can_filter_st.FilterID1 = 0x00000000;
  can_filter_st.FilterID2 = 0x00000000;                     //ä¸čżćť?
	
  HAL_FDCAN_ConfigFilter(&hfdcan2, &can_filter_st); //ĺ°ä¸čż°ĺć°éç˝Žĺ°čżćť¤ĺ?
	HAL_FDCAN_ConfigGlobalFilter(&hfdcan2, FDCAN_REJECT, FDCAN_REJECT, FDCAN_REJECT_REMOTE, FDCAN_REJECT_REMOTE); //éç˝Žĺ¨ĺąčżćť¤
  HAL_FDCAN_Start(&hfdcan2); //ä˝żč˝FDCAN2
  HAL_FDCAN_ActivateNotification(&hfdcan2, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0); //ä˝żč˝FIFO0ćĽćśä¸­ć­
}

void can_send_vol(float send_vol)
{
	uint8_t TxData[8];
	FDCAN_TxHeaderTypeDef TxHeader; //FDCANĺé?ĺ¤´çťćä˝?
	           
	TxHeader.Identifier = 0x307; //ID
	TxHeader.IdType = FDCAN_STANDARD_ID;              //ć ĺID
	TxHeader.TxFrameType = FDCAN_DATA_FRAME;          //ć°ćŽĺ¸?
	TxHeader.DataLength = FDCAN_DLC_BYTES_8;          //8Bytes
	TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;  
	TxHeader.BitRateSwitch = FDCAN_BRS_OFF;           //ĺłé­ĺŻĺćł˘çšç?
	TxHeader.FDFormat = FDCAN_CLASSIC_CAN;            //çťĺ¸CAN
	TxHeader.TxEventFifoControl = FDCAN_NO_TX_EVENTS; 
	TxHeader.MessageMarker = 0;
memcpy(TxData, &send_vol, sizeof(send_vol));
HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan2, &TxHeader, TxData);
}

void can_send_power(float send_power)
{
	uint8_t TxData[8];
	FDCAN_TxHeaderTypeDef TxHeader; //FDCANĺé?ĺ¤´çťćä˝?
	           
	TxHeader.Identifier = 0x308; //ID
	TxHeader.IdType = FDCAN_STANDARD_ID;              //ć ĺID
	TxHeader.TxFrameType = FDCAN_DATA_FRAME;          //ć°ćŽĺ¸?
	TxHeader.DataLength = FDCAN_DLC_BYTES_8;          //8Bytes
	TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;  
	TxHeader.BitRateSwitch = FDCAN_BRS_OFF;           //ĺłé­ĺŻĺćł˘çšç?
	TxHeader.FDFormat = FDCAN_CLASSIC_CAN;            //çťĺ¸CAN
	TxHeader.TxEventFifoControl = FDCAN_NO_TX_EVENTS; 
	TxHeader.MessageMarker = 0;
		
	memcpy(TxData, &send_power, sizeof(send_power));

	HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan2, &TxHeader, TxData);
}

canRev_t canRevData; //ć°ćŽćĽćśçťćä˝?

void HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef *hfdcan, uint32_t RxFifo0ITs) //FIFO0ćĽćśä¸­ć­ĺč°
{
	uint8_t RxData[8];
	FDCAN_RxHeaderTypeDef RxHeader; //FDCANćĽćśĺ¤´çťćä˝
	            
//	HAL_FDCAN_GetRxMessage(&hfdcan2, FDCAN_RX_FIFO0, &RxHeader, RxData); //sbĺĺťéĺ­ŚCčŻ­č¨
	HAL_FDCAN_GetRxMessage(hfdcan, FDCAN_RX_FIFO0, &RxHeader, RxData); 
	
	if(RxHeader.Identifier == 0x306) //ID check
	{
		memcpy(&canRevData, RxData, sizeof(canRev_t));
	}
}
/* USER CODE END 1 */

